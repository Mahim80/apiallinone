import { execFile } from "node:child_process";
import { PNG } from "pngjs";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const MAX_PDF_BYTES = 10 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 12 * 1024 * 1024;

type CommandResult = { stdout: string; stderr: string; error?: string };

export type PdfExtraction = {
  method: "text" | "ocr" | "text+ocr";
  fields: Record<string, string | null>;
  rawText: string;
  images: Array<{ role: "user" | "sign"; buffer: Buffer; contentType: string }>;
  diagnostics: {
    pdfToText: boolean;
    ocr: boolean;
    bengaliOcr: boolean;
    replacementCharactersDetected: boolean;
  };
};

function normalizeBangla(value: string) {
  return value
    .normalize("NFC")
    // Some PDF encoders place Bengali pre-base vowel signs before the consonant.
    .replace(/([িীেৈ])([\u0980-\u09FF])/gu, "$2$1")
    ;
}

function clean(value: string | undefined | null) {
  if (!value) return "";
  const normalized = /�|^[িীেৈ]/u.test(value) ? normalizeBangla(value) : value;
  return normalized
    .replace(/\s+/gu, " ")
    .replace(/�+/gu, "")
    .replace(/[¢»]+\s*$/gu, "")
    .replace(/\s*(?:\*\s*OTHER|Smart\s*Card\s*Info|License\s*Documents|VOTER\s*FORM).*$/iu, "")
    .trim();
}

function toBanglaDigits(value: string) {
  return value.replace(/[0-9]/gu, (digit) => "০১২৩৪৫৬৭৮৯"[Number(digit)]);
}

function cleanPersonName(value: string) {
  return clean(value)
    .replace(/^(?:[A-Za-z]+[\s|]*)+(?=[\u0980-\u09FF])/u, "")
    .replace(/\s*\*+\s*$/u, "")
    .replace(/\s+[0-9০-৯]+\s*$/u, "")
    .replace(/[\s•·|,.;:]+$/u, "")
    .replace(/ভূ\s+ইয়া/gu, "ভূইয়া")
    .replace(/^(?:মাঃ|মোঃ|মেঃ)(?=\s)/u, "মোঃ")
    .replace(/^(?:মাছাঃ|মোছাঃ|মেছাঃ)(?=\s)/u, "মোছাঃ")
    .replace(/^(?:মাসাঃ|মোসাঃ|মেসাঃ)(?=\s)/u, "মোসাঃ")
    .trim();
}

function cleanBanglaName(value: string) {
  return cleanPersonName(value)
    .replace(/শরিফু\s+ল/gu, "শরিফুল")
    .replace(/শরীফু\s+ল/gu, "শরীফুল");
}

function cleanEnglishName(value: string) {
  return clean(value)
    .replace(/^[^A-Za-z]+/u, "")
    .replace(/\s+[A-Z]\s+AY\s*$/iu, "")
    .replace(/\s+(?:RES|ES)\s*$/iu, "")
    .replace(/\s+[0-9]+\s*$/u, "")
    .trim();
}

function getPersonField(text: string, label: string) {
  const labels = "Mother\\s*Name|Mother\\s+.+?\\s+Name|Spouse\\s+Name|Gender|Marital|Occupation|Disability|Birth\\s+Other|Birth\\s+Registration|No\\b|Voter\\s+Documents|License\\s+Documents|Smart\\s+Card\\s+Info|DATA\\s+ENTRY|BIRTH_CERTIFICATE|VOTER\\s+FORM";
  const match = new RegExp(`${label}\\s*([\\s\\S]*?)(?=\\s+(?:${labels})\\b|$)`, "iu").exec(text);
  let value = cleanPersonName(match?.[1] || "");
  if (/Mother/i.test(label) && !value) {
    const splitLabel = /Mother\s+(.+?)\s+Name\s*(?=[.。]|Spouse\s|Gender\s|$)/iu.exec(text);
    value = cleanPersonName(splitLabel?.[1] || "");
  }
  return value;
}

function cleanBirthPlace(value: string) {
  return clean(value).replace(/\s+[০-৯0-9]{3,6}\s*$/u, "").trim();
}

function cleanLocation(value: string) {
  return clean(value)
    .replace(/^Village\s*\/\s*Road\s*/iu, "")
    .replace(/\s+(?:(?:Additional\s+)?Mouza\s*\/\s*Moholla|Village\s*\/\s*Road|Home\s*\/\s*Holding|Post\s+Office|Postal\s+Code|Region)\b[\s\S]*$/iu, "")
    .replace(/^(?:Mouza|Moholla)\s*[,.\/-]*$/iu, "")
    .replace(/\s+(?:Address|For)\s*$/iu, "")
    .trim();
}

function isPlaceholderLocation(value: string) {
  return !value || /^(?:No|Union|Porishod|Holding\s*No|Additional|Mouza|Moholla|For|Address|-)$/iu.test(value);
}

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getField(text: string, start: string, end: string) {
  const flexibleStart = escapeRegex(start).replace(/ /gu, "\\s*");
  const flexibleEnd = escapeRegex(end).replace(/ /gu, "\\s*");
  const expression = new RegExp(
    `${flexibleStart}\\s*(.*?)\\s*${flexibleEnd}`,
    "isu",
  );
  const match = expression.exec(text);
  if (match?.[1]) return clean(match[1]);

  // Some PDFs end a section without printing the next label. In that case,
  // use the rest of the current line instead of returning an empty value.
  const lineExpression = new RegExp(
    `${flexibleStart}[ \\t:：]+([^\\r\\n]+)`,
    "iu",
  );
  return clean(lineExpression.exec(text)?.[1]);
}

function getFirstMatch(text: string, expressions: RegExp[]) {
  for (const expression of expressions) {
    const match = expression.exec(text);
    if (match?.[1]) return clean(match[1]);
  }
  return "";
}

export function formatAddress(text: string) {
  const presentMatch = text.match(/Present\s*Address([\s\S]*?)(?=Permanent\s*Address|Education\b|$)/iu);
  const present = presentMatch?.[1] || text;
  const readAddressField = (start: string, end: string) =>
    cleanLocation(getField(present, start, end)) || cleanLocation(getField(text, start, end));
  const district = readAddressField("District", "RMO");
  let upozila = readAddressField("Upozila", "Union/Ward");
  const splitUpozila = text.match(
    /Upozila\s+([^\r\n]+?)\s+Union\/Ward[^\r\n]*\r?\n\s*([\u0980-\u09FF][^\r\n]*)/iu,
  );
  if (splitUpozila?.[1] && splitUpozila[2] && !/[A-Za-z/]/u.test(splitUpozila[2])) {
    upozila = cleanLocation(`${splitUpozila[1]} ${splitUpozila[2]}`);
  }
  let village = cleanLocation(getField(present, "Village/Road", "Union"));
  const additionalVillage = present.match(
    /Additional\s+Village\/Road\s+(.+?)(?=\s+Home\/Holding|\s+Post\s+Office|$)/iu,
  )?.[1];
  if (isPlaceholderLocation(village)) {
    village = cleanLocation(additionalVillage || "");
  }
  if (isPlaceholderLocation(village)) {
    const fallbackVillage = [
      getField(present, "Additional Mouza/Moholla", "Ward For"),
      getField(present, "Mouza/Moholla", "Ward For"),
      getFirstMatch(present, [
        /Mouza\s*\/\s*([^\r\n]+?)(?=\s+Additional|\s*$)/iu,
        /Additional\s+([^\r\n]+?)(?=\s+Home\/|\s+Mouza\/|\s+Ward\s+For|$)/iu,
      ]),
    ].map(cleanLocation).find(value => !isPlaceholderLocation(value));
    village = fallbackVillage || "";
  }
  if (isPlaceholderLocation(village)) {
    village = getFirstMatch(text, [
      /Additional\s+Village\/Road\s+(.+?)(?=\s+Home\/Holding|\s+Post\s*Office|$)/iu,
      /Additional\s+(.+?)(?=\s+Home\/Holding|\s+Post\s*Office|\s+Ward\s+For|$)/iu,
    ]);
  }
  village = cleanLocation(village.replace(/^Additional\s*/iu, ""));
  const holdingMatch = present.match(
    /Home\/Holding\s*(?:No\s*)?([০-৯0-9]{1,10})/iu,
  );
  const holding = holdingMatch?.[1] ? toBanglaDigits(holdingMatch[1]) : "";
  const postOffice = readAddressField("Post Office", "Postal Code")
    || cleanLocation(present.match(/Post\s+(.+?)\s+Postal\s+/iu)?.[1] || "")
    || cleanLocation(text.match(/Post\s+(.+?)\s+Postal\s+/iu)?.[1] || "")
    || cleanLocation(present.match(/Post\s+(.+?)\s+Office/iu)?.[1] || "")
    || cleanLocation(text.match(/Post\s+(.+?)\s+Office/iu)?.[1] || "");
  const postalCode = readAddressField("Postal Code", "Region")
    || cleanLocation(present.match(/Postal\s+([০-৯0-9]{3,6})\s+(?:Office\s+)?Code/iu)?.[1] || "")
    || cleanLocation(text.match(/Postal\s+([০-৯0-9]{3,6})\s+(?:Office\s+)?Code/iu)?.[1] || "");
  const parts: string[] = [];
  if (holding) parts.push(`বাসা/হোল্ডিং: ${holding}`);
  parts.push(`গ্রাম/রাস্তা: ${village}`);
  if (postOffice) parts.push(`ডাকঘর: ${postOffice}${postalCode ? ` - ${toBanglaDigits(postalCode)}` : ""}`);
  if (upozila) parts.push(upozila);
  if (district) parts.push(district);
  return parts.filter((part, index) => index === 0 || part !== parts[index - 1]).join(", ");
}

function addressScore(value: string) {
  return (value ? 1 : 0)
    + (value.includes("ডাকঘর") ? 4 : 0)
    + (value.includes("বাসা/হোল্ডিং") ? 2 : 0)
    + (value.includes(" - ") ? 2 : 0)
    + (value.match(/,/gu)?.length || 0);
}

async function run(command: string, args: string[], timeout = 45_000): Promise<CommandResult> {
  try {
    const result = await execFileAsync(command, args, {
      timeout,
      maxBuffer: MAX_OUTPUT_BYTES,
      windowsHide: true,
    });
    return { stdout: result.stdout ?? "", stderr: result.stderr ?? "" };
  } catch (error) {
    const typed = error as NodeJS.ErrnoException & { stdout?: string; stderr?: string };
    return {
      stdout: typed.stdout ?? "",
      stderr: typed.stderr ?? "",
      error: typed.code === "ENOENT" ? `${command} is not installed` : typed.message,
    };
  }
}

async function hasCommand(command: string) {
  const result = await run("sh", ["-lc", `command -v ${command}`], 5_000);
  return !result.error && result.stdout.trim().length > 0;
}

async function getTesseractLanguages() {
  const result = await run("tesseract", ["--list-langs"], 10_000);
  const languages = result.stdout.split(/\r?\n/gu).map((item) => item.trim());
  return {
    available: !result.error,
    bengali: languages.includes("ben"),
  };
}

async function extractWithOcr(pdfPath: string, tempDir: string) {
  const [pdftoppmAvailable, tesseractAvailable] = await Promise.all([
    hasCommand("pdftoppm"),
    hasCommand("tesseract"),
  ]);

  if (!pdftoppmAvailable || !tesseractAvailable) {
    return { text: "", available: false, bengali: false };
  }

  const languages = await getTesseractLanguages();
  const language = languages.bengali ? "ben+eng" : "eng";
  const prefix = path.join(tempDir, "page");
  const render = await run("pdftoppm", ["-png", "-r", "180", pdfPath, prefix], 45_000);

  if (render.error) {
    return { text: "", available: true, bengali: languages.bengali };
  }

  const files = (await fs.readdir(tempDir))
    .filter((file) => /^page-\d+\.png$/u.test(file))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  const pages: string[] = [];
  for (const file of files) {
    const imagePath = path.join(tempDir, file);
    const ocr = await run(
      "tesseract",
      [imagePath, "stdout", "-l", language, "--psm", "6"],
      90_000,
    );
    if (ocr.stdout.trim()) pages.push(ocr.stdout);
  }

  return {
    text: pages.join("\n"),
    available: true,
    bengali: languages.bengali,
  };
}

export function composeSoftMask(baseBuffer: Buffer, maskBuffer: Buffer) {
  const base = PNG.sync.read(baseBuffer);
  const mask = PNG.sync.read(maskBuffer);
  if (base.width !== mask.width || base.height !== mask.height) return baseBuffer;

  const output = new PNG({ width: base.width, height: base.height });
  for (let offset = 0; offset < output.data.length; offset += 4) {
    const pixel = offset / 4;
    const baseOffset = pixel * 4;
    const maskValue = mask.data[baseOffset];
    output.data[offset] = base.data[baseOffset];
    output.data[offset + 1] = base.data[baseOffset + 1];
    output.data[offset + 2] = base.data[baseOffset + 2];
    output.data[offset + 3] = maskValue;
  }
  return PNG.sync.write(output);
}

async function extractEmbeddedImages(pdfPath: string, tempDir: string) {
  if (!(await hasCommand("pdfimages"))) return [];

  const prefix = path.join(tempDir, "embedded");
  // PNG mode gives us a consistent format and lets us preserve PDF soft masks.
  const result = await run("pdfimages", ["-png", pdfPath, prefix], 45_000);
  if (result.error) return [];

  const files = (await fs.readdir(tempDir))
    .filter((file) => /^embedded-\d+\.png$/iu.test(file))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  const images: Array<{ role: "user" | "sign"; buffer: Buffer; contentType: string }> = [];
  let imageIndex = 0;
  for (let fileIndex = 0; fileIndex < files.length && imageIndex < 2; fileIndex += 1) {
    const baseBuffer = await fs.readFile(path.join(tempDir, files[fileIndex]));
    let outputBuffer = baseBuffer;

    // Poppler emits a soft mask immediately after its source image. Compositing
    // it here prevents the opaque black source bitmap from becoming the preview.
    if (fileIndex + 1 < files.length) {
      const nextBuffer = await fs.readFile(path.join(tempDir, files[fileIndex + 1]));
      const base = PNG.sync.read(baseBuffer);
      const mask = PNG.sync.read(nextBuffer);
      if (base.width === mask.width && base.height === mask.height && mask.colorType === 0) {
        outputBuffer = composeSoftMask(baseBuffer, nextBuffer);
        fileIndex += 1;
      }
    }

    images.push({
      role: imageIndex === 0 ? "user" : "sign",
      buffer: outputBuffer,
      contentType: "image/png",
    });
    imageIndex += 1;
  }
  return images;
}

export function parseFields(text: string) {
  const nidFromLabel = getFirstMatch(text, [
    /National\s*ID\s*([0-9]{10,17})/iu,
    /National\s*ID\s*[:：]?\s*([0-9\s]{10,25})/iu,
  ]).replace(/\D/gu, "");
  const nid = /^\d{10,17}$/u.test(nidFromLabel)
    ? nidFromLabel
    : (text.match(/(?<!\d)\d{10}(?!\d)/u)?.[0] ?? "");

  const dob = getField(text, "Date of Birth", "Birth Place");
  const dateOfBirth = dob.match(/\d{4}-\d{2}-\d{2}/u)?.[0] || clean(dob);

  return {
    nationalId: nid,
    pin: getField(text, "Pin", "Status").replace(/\D/gu, ""),
    status: getField(text, "Status", "Afis Status"),
    afisStatus: getField(text, "Afis Status", "Lock Flag"),
    lockFlag: getField(text, "Lock Flag", "Voter No"),
    voterNo: getField(text, "Voter No", "Form No"),
    formNo: getField(text, "Form No", "Sl No"),
    nameBangla: cleanBanglaName(getField(text, "Name(Bangla)", "Name(English)")),
    nameEnglish: cleanEnglishName(getField(text, "Name(English)", "Date of Birth")),
    dateOfBirth,
    birthPlace: cleanBirthPlace(getField(text, "Birth Place", "Birth Other")),
    fatherName: getPersonField(text, "Father\\s*Name"),
    motherName: getPersonField(text, "Mother\\s*Name"),
    spouseName: getField(text, "Spouse Name", "Gender"),
    gender: getField(text, "Gender", "Marital")
      .replace(/\s+No\s+Documents.*$/iu, "")
      .trim(),
    marital: getField(text, "Marital", "Occupation"),
    occupation: getField(text, "Occupation", "Disability"),
    education: getField(text, "Education", "Education Other"),
    identification: getField(text, "Identification", "Blood Group"),
    bloodGroup: getField(text, "Blood Group", "TIN"),
    religion: getField(text, "Religion", "Religion Other"),
    laptopId: getField(text, "Laptop ID", "NID Father"),
    voterArea: getField(text, "Voter Area", "Voter At"),
    address: formatAddress(text),
  };
}

export async function extractPdfDocument(buffer: Buffer): Promise<PdfExtraction> {
  if (buffer.length === 0) throw new Error("The uploaded PDF is empty.");
  if (buffer.length > MAX_PDF_BYTES) throw new Error("PDF must be 10 MB or smaller.");
  if (buffer.subarray(0, 5).toString("ascii") !== "%PDF-") {
    throw new Error("The uploaded file is not a valid PDF.");
  }

  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "bangla-pdf-"));
  const pdfPath = path.join(tempDir, "document.pdf");
  await fs.writeFile(pdfPath, buffer, { mode: 0o600 });

  try {
    const pdfToTextAvailable = await hasCommand("pdftotext");
    const textResult = pdfToTextAvailable
      ? await run("pdftotext", ["-layout", pdfPath, "-"], 45_000)
      : { stdout: "", stderr: "", error: "pdftotext is not installed" };
    const text = textResult.stdout.trim();
    const replacementCharactersDetected = text.includes("�");
    const brokenBanglaSpacing = (text.match(/[\u0980-\u09FF] [\u0980-\u09FF]/gu) || []).length > 4;
    // Some Bengali fonts insert spaces inside words (e.g. "চাকু রী").
    // Only use the slower OCR path when that pattern is actually detected.
    const textLooksUseful = /National\s*ID/iu.test(text)
      && !replacementCharactersDetected
      && !brokenBanglaSpacing;

    let finalText = text;
    let method: PdfExtraction["method"] = "text";
    let ocrAvailable = false;
    let bengaliOcr = false;

    if (!textLooksUseful) {
      const ocr = await extractWithOcr(pdfPath, tempDir);
      ocrAvailable = ocr.available;
      bengaliOcr = ocr.bengali;
      if (ocr.text.trim()) {
        finalText = ocr.text.trim();
        method = text ? "text+ocr" : "ocr";
      }
    }

    if (!finalText.trim()) {
      throw new Error(
        "No text was extracted. The preview runtime needs pdftotext and Bengali Tesseract OCR.",
      );
    }

    const images = await extractEmbeddedImages(pdfPath, tempDir);
    const finalFields: Record<string, string> = parseFields(finalText);
    const originalFields: Record<string, string> = text && finalText !== text
      ? parseFields(text)
      : finalFields;
    const mergedFields = Object.fromEntries(
      Object.keys(finalFields).map((key) => [
        key,
        finalFields[key] || originalFields[key] || "",
      ]),
    );
    const hasBanglaPrefix = (value: string) => /^ম(?:ো|ে|া)/u.test(value);
    for (const key of ["nameBangla", "fatherName", "motherName"]) {
      if (hasBanglaPrefix(originalFields[key] || "") && !hasBanglaPrefix(finalFields[key] || "")) {
        mergedFields[key] = originalFields[key];
      }
    }
    mergedFields.address = [finalFields.address, originalFields.address]
      .sort((a, b) => addressScore(b) - addressScore(a))[0] || "";

    return {
      method,
      fields: mergedFields,
      rawText: finalText,
      images,
      diagnostics: {
        pdfToText: pdfToTextAvailable && !textResult.error,
        ocr: ocrAvailable,
        bengaliOcr,
        replacementCharactersDetected,
      },
    };
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }
}

export function extractionRuntimeHealth() {
  return {
    maxPdfSizeMb: MAX_PDF_BYTES / 1024 / 1024,
    note: "Uploaded PDFs are processed in temporary memory/disk and deleted after extraction.",
  };
}
