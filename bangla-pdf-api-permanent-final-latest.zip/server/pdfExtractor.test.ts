import { describe, expect, it } from "vitest";
import { formatAddress, parseFields } from "./pdfExtractor";

describe("PDF field extraction", () => {
  it("parses a normal NID PDF text layer", () => {
    const text = `
National ID          3718621612
Pin                  19782619351963315
Status               printed
Afis Status          NO_MATCH
Lock Flag            N
Name(Bangla)         মোঃ আঃ সালাম
Name(English)        Md Abdul Salam
Date of Birth        1978-01-01
Birth Place          টাঙ্গাইল
Father Name          মোঃ মকবুল হোসেন
Mother Name          মোছাঃ ফাতেমা খাতুন
Spouse Name          মোছাঃ রহিমা খাতুন
Gender               male
Marital              married
Occupation           বেসরকারী চাকুরী
Education            ৮ম শ্রেণী
Religion             Islam
`;

    const result = parseFields(text);

    expect(result.nationalId).toBe("3718621612");
    expect(result.nameBangla).toContain("সালাম");
    expect(result.nameEnglish).toBe("Md Abdul Salam");
    expect(result.dateOfBirth).toBe("1978-01-01");
    expect(result.fatherName).toContain("মকবুল");
    expect(result.motherName).toBe("মোছাঃ ফাতেমা খাতুন");
    expect(result.spouseName).toBe("মোছাঃ রহিমা খাতুন");
    expect(result.occupation).toContain("চাকুরী");
  });

  it("removes trailing document labels from names", () => {
    const text = `Mother Name মোছাঃ পশিলা বেগম * OTHER
Spouse Name মোছাঃ খতেজা বেগম Smart Card Info
Gender male`;
    const result = parseFields(text);
    expect(result.motherName).toBe("মোছাঃ পশিলা বেগম");
    expect(result.spouseName).toBe("মোছাঃ খতেজা বেগম");
  });

  it("keeps only the ISO date from a noisy date field", () => {
    const result = parseFields("Date of Birth 1978-01-01 ০৮০০০ Birth Place টাঙ্গাইল");
    expect(result.dateOfBirth).toBe("1978-01-01");
  });

  it("removes adjacent OCR labels from English name, gender, and birthplace", () => {
    const text = `Name(English) | SOYALUDDIN MOLLAH B AY
Date of Birth 1971-10-17
Birth Place সাতক্ষীরা ৯২২২২ Birth Other
Gender male No Documents Marital married`;
    const result = parseFields(text);
    expect(result.nameEnglish).toBe("SOYALUDDIN MOLLAH");
    expect(result.birthPlace).toBe("সাতক্ষীরা");
    expect(result.gender).toBe("male");
  });

  it("parses names when OCR splits Mother Name across the value", () => {
    const result = parseFields(`Father Name করিম বক্স মোল্যা Mother সুখজান বিবি Name . Spouse রাজিয়া খাতুন License Name Documents Gender male`);
    expect(result.fatherName).toBe("করিম বক্স মোল্যা");
    expect(result.motherName).toBe("সুখজান বিবি");
  });

  it("removes Latin OCR noise before Bengali parent names", () => {
    const result = parseFields("Father Name ans রুহুল আমীন Mother Name CATES আকলিমা বেগম Spouse Name Gender male");
    expect(result.fatherName).toBe("রুহুল আমীন");
    expect(result.motherName).toBe("আকলিমা বেগম");
  });

  it("keeps Bengali name prefixes while removing Latin noise", () => {
    const result = parseFields("Name(Bangla) care মোছাঃ শরিফুল ইসলাম Name(English) Md Test Date of Birth 1970-01-01");
    expect(result.nameBangla).toBe("মোছাঃ শরিফুল ইসলাম");
  });

  it("joins the OCR-split শরিফু ল name", () => {
    const result = parseFields("Name(Bangla) মোঃ শরিফু ল ইসলাম Name(English) MD SARIFUL ISLAM Date of Birth 1993-09-08");
    expect(result.nameBangla).toBe("মোঃ শরিফুল ইসলাম");
  });

  it("stops parent names before document labels", () => {
    const result = parseFields("Father Name মাঃ শাহজাহান ভূঁইয়া DATA ENTRY PROOF COPY Mother Name মোসাঃ মাজেদা বেগম Spouse Name");
    expect(result.fatherName).toBe("মোঃ শাহজাহান ভূঁইয়া");
    expect(result.motherName).toBe("মোসাঃ মাজেদা বেগম");
  });

  it("joins OCR-split Bengali surname characters", () => {
    const result = parseFields("Father Name মাঃ শাহজাহান ভূ ইয়া Mother Name মোসাঃ মাজেদা বেগম");
    expect(result.fatherName).toBe("মোঃ শাহজাহান ভূইয়া");
  });

  it("falls back to address labels when Present Address is missing", () => {
    const address = formatAddress(`Division খুলনা District সাতক্ষীরা
Upozila কালীগঞ্জ Union/Ward কুশুলিয়া
Mouza/Moholla Additional কুশুলিয়া
Post Office নলতা Postal Code 9440
Region খুলনা Permanent Address`);
    expect(address).toContain("গ্রাম/রাস্তা: কুশুলিয়া");
    expect(address).toContain("ডাকঘর: নলতা - ৯৪৪০");
  });

  it("parses the full Khulna address block without duplicating district", () => {
    const address = formatAddress(`Present Address Division খুলনা District সাতক্ষীরা
RMO পল্লী (1) City Corporation Or Municipality
Upozila সাতক্ষীরা সদর Union/Ward িফংড়ী
Mouza/Moholla Additional Mouza/Moholla ফয়জুলাপুর
Ward For Union Porishod 3 Village/Road Additional Village/Road ফয়জুলাপুর
Home/Holding No Post Office ব্রহ্মরাজপুর Postal Code 9400
Region খুলনা Permanent Address`);
    expect(address).toBe("গ্রাম/রাস্তা: ফয়জুলাপুর, ডাকঘর: ব্রহ্মরাজপুর - ৯৪০০, সাতক্ষীরা সদর, সাতক্ষীরা");
  });

  it("accepts OCR labels with missing spaces", () => {
    const address = formatAddress(`PresentAddress Division খুলনা District সাতক্ষীরা
Upozila সাতক্ষীরা সদর Union/Ward ফিংড়ী
Additional ফয়জুল্যাপুর Village/Road No
PostOffice ব্রহ্মরাজপুর PostalCode 9400 Region খুলনা PermanentAddress`);
    expect(address).toContain("ডাকঘর: ব্রহ্মরাজপুর - ৯৪০০");
    expect(address).toContain("সাতক্ষীরা সদর");
  });

  it("parses flattened Additional Village/Road address text", () => {
    const address = formatAddress(`Present Address Division খুলনা District সাতক্ষীরা RMO পল্লী (1) City Corporation Or Municipality Upozila সাতক্ষীরা সদর Union/Ward িফংড়ী Mouza/Moholla Additional Mouza/Moholla ফয়জুলাপুর Ward For Union Porishod 3 Village/Road Additional Village/Road ফয়জুলাপুর Home/Holding No Post Office ব্রহ্মরাজপুর Postal Code 9400 Region খুলনা`);
    expect(address).toBe("গ্রাম/রাস্তা: ফয়জুলাপুর, ডাকঘর: ব্রহ্মরাজপুর - ৯৪০০, সাতক্ষীরা সদর, সাতক্ষীরা");
  });

  it("recovers a ten-digit NID when the label is damaged", () => {
    const text = "National ID 3280317789 Pin 19589410852562758 Status checked";
    expect(parseFields(text).nationalId).toBe("3280317789");
  });

  it("does not invent a NID when no ten-digit identifier exists", () => {
    const text = "Name(English) Example Person Date of Birth 1958-01-03";
    expect(parseFields(text).nationalId).toBe("");
  });

  it("uses Additional Mouza as village and converts address digits to Bangla", () => {
    const text = `Present Address Division রংপুর District ঠাকুরগাঁও
Upozila বালিয়াডাঙ্গী Union/Ward চাড়োল
Mouza/Moholla Additional দোগাছি
Ward For 8 Village/Road Holding No
Additional Home/Holding No
Village/Road No
Post Office সনগাও Postal Code 5140
Region রংপুর
Permanent Address`;
    const address = formatAddress(text);
    expect(address).toContain("গ্রাম/রাস্তা: দোগাছি");
    expect(address).toContain("ডাকঘর: সনগাও - ৫১৪০");
    expect(address).toContain("বালিয়াডাঙ্গী");
  });

  it("keeps the clean NIAZ OCR spellings for name and birthplace", () => {
    const result = parseFields(`Name(Bangla) নিয়াজ মোহাম্মদ Name(English) NIAZ MOHAMMED Date of Birth 1970-02-02 Birth Place ব্রাহ্মণবাড়িয়া Birth Other Father Name মোঃ শাহজাহান ভূইয়া Mother Name মোসাঃ মাজেদা বেগম Gender male`);
    expect(result.nameBangla).toBe("নিয়াজ মোহাম্মদ");
    expect(result.birthPlace).toBe("ব্রাহ্মণবাড়িয়া");
    expect(result.fatherName).toBe("মোঃ শাহজাহান ভূইয়া");
  });

  it("removes trailing OCR noise from the English name", () => {
    const result = parseFields("Name(English) Md Siddik RES Date of Birth 1943-01-07 Birth Place নোয়াখালী");
    expect(result.nameEnglish).toBe("Md Siddik");
  });

  it("does not leak Mouza/Moholla into the village address value", () => {
    const address = formatAddress(`Present Address Division রংপুর District ঠাকুরগাঁও Upozila ঠাকুরগাঁও সদর Union/Ward নারগুন Mouza/Moholla Additional কহরপাড়া Mouza/Moholla Ward For 2 Village/Road Additional কহরপাড়া Home/Holding No Village/Road No Post Office কহরপাড়া Postal Code 5100 Region রংপুর Permanent Address`);
    expect(address).toContain("গ্রাম/রাস্তা: কহরপাড়া");
    expect(address).not.toContain("কহরপাড়া Mouza/Moholla");
  });

  it("omits a standalone Moholla placeholder from ASMA-style addresses", () => {
    const address = formatAddress(`Present Address Division ঢাকা District টাঙ্গাইল
Upozila কালিহাতী Union/Ward ওয়ার্ড নং-০৩
Mouza/ সিলিমপুর Additional
Moholla Mouza/
Moholla
Ward For Village/Road
Village/Road Holding No
Post Office কালিহাতি Postal Code 1970
Region ঢাকা Permanent Address`);
    expect(address).toBe("গ্রাম/রাস্তা: সিলিমপুর, ডাকঘর: কালিহাতি - ১৯৭০, কালিহাতী, টাঙ্গাইল");
    expect(address).not.toContain("গ্রাম/রাস্তা: Moholla");
  });

  it("keeps the village label when every location value is empty", () => {
    const address = formatAddress(`Present Address Division ঢাকা District টাঙ্গাইল
Upozila কালিহাতী Union/Ward ওয়ার্ড নং-০৩
Mouza/ Additional
Moholla
Ward For Village/Road
Village/Road No
Post Office কালিহাতি Postal Code 1970
Region ঢাকা Permanent Address`);
    expect(address).toContain("গ্রাম/রাস্তা:");
    expect(address).not.toContain("Moholla");
  });

  it("prefers a valid Village/Road over Additional and Mouza values", () => {
    const address = formatAddress(`Present Address Division ঢাকা District টাঙ্গাইল
Upozila কালিহাতী Union/Ward ওয়ার্ড নং-০৩
Mouza/ আসল-মৌজা Additional বিকল্প-গ্রাম
Ward For Village/Road আসল-গ্রাম Home/Holding No
Post Office কালিহাতি Postal Code 1970
Region ঢাকা Permanent Address`);
    expect(address).toContain("গ্রাম/রাস্তা: আসল-গ্রাম");
    expect(address).not.toContain("বিকল্প-গ্রাম");
    expect(address).not.toContain("আসল-মৌজা");
  });

  it("removes trailing PDF noise symbols from parent names", () => {
    const result = parseFields("Father Name মোঃ আববাস আলী ¢ Mother Name মোছাঃ আলেয়া খাতুন » Gender female");
    expect(result.fatherName).toBe("মোঃ আববাস আলী");
    expect(result.motherName).toBe("মোছাঃ আলেয়া খাতুন");
  });
});
