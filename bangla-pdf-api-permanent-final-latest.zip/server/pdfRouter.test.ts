import { describe, expect, it, vi } from "vitest";
import { PNG } from "pngjs";

const extracted = {
  method: "text" as const,
  rawText: "National ID 1234567890",
  fields: { nationalId: "1234567890", nameBangla: "আসমা", nameEnglish: "ASMA", address: "ঢাকা" },
  images: [{ role: "user" as const, buffer: Buffer.from("portrait"), contentType: "image/png" }, { role: "sign" as const, buffer: Buffer.from("signature"), contentType: "image/png" }],
  diagnostics: { pdfToText: true, ocr: false, bengaliOcr: false, replacementCharactersDetected: false },
};

vi.mock("./pdfExtractor", async () => {
  const actual = await vi.importActual<typeof import("./pdfExtractor")>("./pdfExtractor");
  return { ...actual, extractPdfDocument: vi.fn(async () => extracted) };
});
vi.mock("./storage", () => ({ storagePut: vi.fn(async (key: string) => ({ key, url: `/manus-storage/${key}` })) }));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function caller() {
  const ctx: TrpcContext = {
    user: undefined,
    req: { protocol: "https", headers: {}, get: () => undefined } as unknown as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
  return appRouter.createCaller(ctx);
}

describe("pdf.extract validation and response", () => {
  it("rejects non-PDF MIME types before processing", async () => {
    await expect(caller().pdf.extract({ fileName: "id.txt", mimeType: "text/plain", contentBase64: "aA==" })).rejects.toThrow("Please upload a PDF file.");
  });

  it("rejects an empty encoded payload", async () => {
    await expect(caller().pdf.extract({ fileName: "id.pdf", mimeType: "application/pdf", contentBase64: "" })).rejects.toThrow();
  });

  it("rejects an oversized encoded payload", async () => {
    await expect(caller().pdf.extract({ fileName: "id.pdf", mimeType: "application/pdf", contentBase64: "a".repeat(14_000_001) })).rejects.toThrow();
  });

  it("returns the documented success shape with extracted fields and image links", async () => {
    const result = await caller().pdf.extract({ fileName: "id.pdf", mimeType: "application/pdf", contentBase64: Buffer.from("%PDF-test").toString("base64") });
    expect(result).toMatchObject({ code: 200, success: true, message: "Data fetched successfully" });
    expect(result.data).toMatchObject({ nationalId: "1234567890", nameBangla: "আসমা", nameEnglish: "ASMA" });
    expect(result.data.userIMG).toContain("/manus-storage/");
    expect(result.data.signIMG).toContain("/manus-storage/");
  });

  it("returns a valid PNG payload for a transparent image fixture", () => {
    const png = new PNG({ width: 1, height: 1 });
    png.data.set([0, 0, 0, 0]);
    expect(PNG.sync.read(PNG.sync.write(png)).data[3]).toBe(0);
  });
});
