import { describe, expect, it } from "vitest";
import { PNG } from "pngjs";
import { composeSoftMask } from "./pdfExtractor";

describe("signature soft-mask compositing", () => {
  it("turns the opaque source background transparent and keeps mask opacity", () => {
    const base = new PNG({ width: 2, height: 1 });
    base.data.set([0, 0, 0, 255, 0, 0, 0, 255]);
    const mask = new PNG({ width: 2, height: 1, colorType: 0 });
    mask.data.set([255, 0, 0, 0, 0, 0, 0, 0]);
    const result = PNG.sync.read(composeSoftMask(PNG.sync.write(base), PNG.sync.write(mask)));
    expect(result.data[3]).toBe(255);
    expect(result.data[7]).toBe(0);
  });
});
