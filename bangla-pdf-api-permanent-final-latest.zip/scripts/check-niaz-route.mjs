import { readFile } from "node:fs/promises";
import { PNG } from "pngjs";
import { appRouter } from "../server/routers.ts";

const buffer = await readFile("/home/ubuntu/upload/NIAZ.pdf");
const ctx = {
  user: undefined,
  req: { protocol: "https", headers: {}, get: (name) => name.toLowerCase() === "host" ? "3000-i05wkydcte8dpz58cjfoh-94ba22cc.us4.manus.computer" : undefined },
  res: {},
};
const result = await appRouter.createCaller(ctx).pdf.extract({
  fileName: "NIAZ.pdf",
  mimeType: "application/pdf",
  contentBase64: buffer.toString("base64"),
});
if (result.data.nameBangla !== "নিয়াজ মোহাম্মদ") throw new Error(`Unexpected nameBangla: ${result.data.nameBangla}`);
if (result.data.birthPlace !== "ব্রাহ্মণবাড়িয়া") throw new Error(`Unexpected birthPlace: ${result.data.birthPlace}`);
if (!result.data.userIMG?.endsWith(".png") || !result.data.signIMG?.endsWith(".png")) throw new Error("Expected PNG image links");
const signatureResponse = await fetch(result.data.signIMG);
if (!signatureResponse.ok) throw new Error(`Signature asset fetch failed: ${signatureResponse.status}`);
const signature = PNG.sync.read(Buffer.from(await signatureResponse.arrayBuffer()));
let transparentPixels = 0;
let visiblePixels = 0;
for (let i = 0; i < signature.data.length; i += 4) { if (signature.data[i + 3] < 255) transparentPixels += 1; if (signature.data[i + 3] > 0) visiblePixels += 1; }
if (transparentPixels === 0 || visiblePixels === 0) throw new Error("Signature asset is not transparently composited");
console.log(JSON.stringify({ code: result.code, success: result.success, nameBangla: result.data.nameBangla, birthPlace: result.data.birthPlace, userIMG: result.data.userIMG, signIMG: result.data.signIMG, signature: { width: signature.width, height: signature.height, transparentPixels, visiblePixels } }, null, 2));
