import { readFile } from "node:fs/promises";
import { PNG } from "pngjs";
import { extractPdfDocument } from "../server/pdfExtractor.ts";

const result = await extractPdfDocument(await readFile("/home/ubuntu/upload/NIAZ.pdf"));
console.log(JSON.stringify({
  method: result.method,
  nameBangla: result.fields.nameBangla,
  birthPlace: result.fields.birthPlace,
  address: result.fields.address,
  diagnostics: result.diagnostics,
  signature: (() => { const image = result.images.find((item) => item.role === "sign"); if (!image) return null; const png = PNG.sync.read(image.buffer); let transparentPixels = 0; for (let i = 3; i < png.data.length; i += 4) if (png.data[i] < 255) transparentPixels += 1; return { contentType: image.contentType, width: png.width, height: png.height, transparentPixels }; })(),
}, null, 2));
if (result.fields.nameBangla !== "নিয়াজ মোহাম্মদ" || result.fields.birthPlace !== "ব্রাহ্মণবাড়িয়া") throw new Error("NIAZ fields do not match the expected clean output");
if (!result.images.find((item) => item.role === "sign")) throw new Error("NIAZ signature was not extracted");
