import { readFile } from "node:fs/promises";
import { extractPdfDocument } from "../server/pdfExtractor.ts";

const result = await extractPdfDocument(await readFile("/home/ubuntu/upload/ASMA.pdf"));
console.log(JSON.stringify({ address: result.fields.address, method: result.method, diagnostics: result.diagnostics }, null, 2));
