import { readFile } from "node:fs/promises";
import { appRouter } from "../server/routers.ts";

const buffer = await readFile("/home/ubuntu/upload/ASMA.pdf");
const ctx = {
  user: undefined,
  req: { protocol: "https", headers: {}, get: (name) => name.toLowerCase() === "host" ? "3000-i05wkydcte8dpz58cjfoh-94ba22cc.us4.manus.computer" : undefined },
  res: {},
};
const result = await appRouter.createCaller(ctx).pdf.extract({ fileName: "ASMA.pdf", mimeType: "application/pdf", contentBase64: buffer.toString("base64") });
if (result.code !== 200 || !result.success) throw new Error("Route did not return a successful response");
if (result.data.address.includes("Moholla") || result.data.address.includes("Mouza/Moholla")) throw new Error(`Placeholder leaked into address: ${result.data.address}`);
if (result.data.address !== "গ্রাম/রাস্তা: সিলিমপুর, ডাকঘর: কালিহাতি - ১৯৭০, কালিহাতী, টাঙ্গাইল") throw new Error(`Unexpected ASMA address: ${result.data.address}`);
console.log(JSON.stringify({ code: result.code, success: result.success, address: result.data.address, signIMG: result.data.signIMG }, null, 2));
