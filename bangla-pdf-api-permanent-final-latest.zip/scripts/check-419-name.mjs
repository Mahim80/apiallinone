import { readFile } from "node:fs/promises";
import { extractPdfDocument } from "../server/pdfExtractor.ts";

const result = await extractPdfDocument(await readFile("/home/ubuntu/upload/4198016687.pdf"));
if (result.fields.nameEnglish !== "Md Siddik") throw new Error(`Unexpected extracted name: ${result.fields.nameEnglish}`);
console.log(JSON.stringify({ nameEnglish: result.fields.nameEnglish, nationalId: result.fields.nationalId, method: result.method }, null, 2));
