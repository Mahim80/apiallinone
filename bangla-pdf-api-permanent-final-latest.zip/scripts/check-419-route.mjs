import { readFile } from "node:fs/promises";
import { appRouter } from "../server/routers.ts";

const buffer = await readFile("/home/ubuntu/upload/4198016687.pdf");
const ctx = {
  user: undefined,
  req: { protocol: "https", headers: {}, get: (name) => name.toLowerCase() === "host" ? "3000-i05wkydcte8dpz58cjfoh-94ba22cc.us4.manus.computer" : undefined },
  res: {},
};
const result = await appRouter.createCaller(ctx).pdf.extract({ fileName: "4198016687.pdf", mimeType: "application/pdf", contentBase64: buffer.toString("base64") });
if (result.code !== 200 || !result.success) throw new Error("Route did not return a successful response");
if (result.data.nameEnglish !== "MD SIDDIK") throw new Error(`Unexpected route nameEnglish: ${result.data.nameEnglish}`);
if (!result.data.signIMG?.endsWith(".png")) throw new Error("Expected the signature link to be PNG");
if (result.data.address !== "গ্রাম/রাস্তা: কহরপাড়া, ডাকঘর: কহরপাড়া - ৫১০০, ঠাকুরগাঁও সদর, ঠাকুরগাও") throw new Error(`Unexpected address: ${result.data.address}`);
console.log(JSON.stringify({ code: result.code, success: result.success, nameEnglish: result.data.nameEnglish, nationalId: result.data.nationalId, address: result.data.address, signIMG: result.data.signIMG }, null, 2));
